package com.example.myapplication;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText val1, val2;
    TextView saida;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        val1 = findViewById(R.id.editTextVal1);
        val2 = findViewById(R.id.editTextVal2);
        saida = findViewById(R.id.textViewSaida);
    }

    public void calcular(View v){
        String val1String = val1.getText().toString();
        String val2String = val2.getText().toString();

        int val1Int = Integer.parseInt(val1String);
        int val2Int = Integer.parseInt(val2String);

        int soma = val1Int + val2Int;
        int sub = val1Int - val2Int;
        int mult = val1Int * val2Int;
        int div = val1Int / val2Int;
        int eq = (val1Int * val1Int + val2Int * val2Int) / 3;


        saida.setText(soma + "$" + sub + "$" + mult + "$" + div);
        saida.setText(eq);

    }
}